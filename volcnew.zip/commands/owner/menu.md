const { MessageEmbed, Client, Message, MessageActionRow, MessageSelectMenu } = require('discord.js');
const db = require('quick.db');

module.exports = {
    name: 'menu',
    category: 'Owner',
    description: 'Test',
    aliases: ['select'],
    usage: 'test',
    userperms: ['BOT_OWNER'],
    botperms: [],
    /**
    * @param {Client} client
    * @param {Message} message
    * @param {String[]} args
    */
    run: async (client, message, args) => {

        const row = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('test')
                    .setPlaceholder('Choose something idk')
                    .addOptions([
                        {
                            label: '',
                        }
                    ])
            )

        message.channel.send({ content: 'Selct', components: [row] })

    }
}